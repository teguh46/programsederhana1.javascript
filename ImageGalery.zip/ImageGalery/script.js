const container = document.querySelector('.container');
const jumbo = document.querySelector('.jumbo');
const thumb = document.querySelectorAll('.thumb');

container.addEventListener('click', function (ganti){
    //cek apakah yang diklik adalah thumb
    if (ganti.target.className == 'thumb') {

        jumbo.src = ganti.target.src;
        jumbo.classList.add('animasi');
        setTimeout(function(){
            jumbo.classList.remove('animasi')
        }, 500);

        thumb.forEach(function(thumb){
           thumb.className = 'thumb';
        });
        
        ganti.target.classList.add('active');
    }
});